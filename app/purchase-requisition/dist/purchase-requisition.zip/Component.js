sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("purchaserequisition.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map